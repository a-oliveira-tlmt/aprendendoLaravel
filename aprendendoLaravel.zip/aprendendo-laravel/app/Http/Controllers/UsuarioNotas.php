<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsuarioNotas extends Controller
{
    public function testeNota(){
		//$nota=83
		//$notamax=100
		//echo "<h1>Sua nota é {{nota}}/{{notamax}}.</h1>"
		echo "<h1>Sua nota é 83/100.</h1>";
		
		//$nota=Nota::where('matricula','2344322');
		//return view( view: 'saidaNota', [
		    //'nota'=$nota
		//]);
		
	}
}
